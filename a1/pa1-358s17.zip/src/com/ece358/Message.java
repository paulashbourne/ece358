package com.ece358;

/**
 * Created by jeff on 2017-06-03.
 */
public abstract class Message {
  abstract byte[] toBytes();
}
